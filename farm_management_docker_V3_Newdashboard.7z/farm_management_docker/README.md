## This repo contains a final year project, a farm management system build using a pern stack
