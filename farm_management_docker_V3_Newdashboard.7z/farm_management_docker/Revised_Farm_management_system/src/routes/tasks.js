// COMPLETE src/routes/tasks.js - Replace your entire file with this
const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { requireDepartmentAccess } = require('../middleware/departmentAccess');
const { 
  getAllTasks, 
  createTask, 
  updateTaskStatus,        // ← Import the new function
  assignTaskToEmployee     // ← Import the new function
} = require('../controllers/taskController');

router.use(authenticateToken, requireDepartmentAccess);

router.get('/', getAllTasks);
router.post('/', createTask);
router.put('/:id/status', updateTaskStatus);          // ← New route
router.post('/assign', assignTaskToEmployee);         // ← New route

console.log('Task routes loaded with updateTaskStatus and assignTaskToEmployee');

module.exports = router;