// COMPLETE taskController.js - Replace your entire file with this
const pool = require('../config/database');
const { handleError } = require('../middleware/errorHandler');

const getAllTasks = async (req, res) => {
  try {
    let query = `
      SELECT t.*, d.name as department_name 
      FROM tasks t 
      LEFT JOIN departments d ON t.department_id = d.id
    `;
    let params = [];
    
    if (req.departmentFilter.department_id) {
      query += ' WHERE t.department_id = $1';
      params.push(req.departmentFilter.department_id);
    }
    
    query += ' ORDER BY t.created_at DESC';
    
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    handleError(res, error, 'Failed to fetch tasks');
  }
};

const createTask = async (req, res) => {
  try {
    const { title, description, priority, due_date, department_id } = req.body;
    
    if (!title) {
      return res.status(400).json({ error: 'Task title is required' });
    }
    
    // Check department access
    if (req.user.role === 'supervisor' && department_id !== req.user.department_id) {
      return res.status(403).json({ error: 'Cannot create task in different department' });
    }
    
    const result = await pool.query(
      'INSERT INTO tasks (title, description, priority, due_date, department_id) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [title, description, priority, due_date, department_id]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (error) {
    handleError(res, error, 'Failed to create task');
  }
};

// NEW FUNCTION - Add this to your taskController.js
const updateTaskStatus = async (req, res) => {
  console.log('=== UPDATE TASK STATUS CALLED ===');
  console.log('Task ID:', req.params.id);
  console.log('Request body:', req.body);
  console.log('User:', req.user.username);
  
  try {
    const { id } = req.params;
    const { status, notes } = req.body;
    
    console.log('Attempting to update task', id, 'to status', status);
    
    if (!['pending', 'in_progress', 'completed'].includes(status)) {
      console.log('Invalid status provided:', status);
      return res.status(400).json({ error: 'Invalid status. Must be pending, in_progress, or completed' });
    }
    
    // Check if user has access to this task's department
    let query = `
      SELECT t.*, d.name as department_name 
      FROM tasks t 
      LEFT JOIN departments d ON t.department_id = d.id 
      WHERE t.id = $1
    `;
    let params = [id];
    
    if (req.departmentFilter && req.departmentFilter.department_id) {
      query += ' AND t.department_id = $2';
      params.push(req.departmentFilter.department_id);
    }
    
    console.log('Checking task access with query:', query, 'params:', params);
    
    const taskCheck = await pool.query(query, params);
    
    if (taskCheck.rows.length === 0) {
      console.log('Task not found or access denied');
      return res.status(404).json({ error: 'Task not found or access denied' });
    }
    
    console.log('Task found:', taskCheck.rows[0]);
    
    // Update the task
    const updateQuery = `
      UPDATE tasks 
      SET status = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2 
      RETURNING *, 
        (SELECT name FROM departments WHERE id = department_id) as department_name
    `;
    
    console.log('Updating with query:', updateQuery);
    
    const result = await pool.query(updateQuery, [status, id]);
    
    console.log('Update successful:', result.rows[0]);
    
    // If task is completed, log it as an activity
    if (status === 'completed') {
      console.log(`Task "${result.rows[0].title}" marked as completed by ${req.user.username}`);
    }
    
    res.json({
      success: true,
      message: 'Task status updated successfully',
      task: result.rows[0]
    });
  } catch (error) {
    console.error('ERROR in updateTaskStatus:', error);
    handleError(res, error, 'Failed to update task status');
  }
};

// NEW FUNCTION - Add this to your taskController.js
const assignTaskToEmployee = async (req, res) => {
  console.log('=== ASSIGN TASK CALLED ===');
  console.log('Request body:', req.body);
  
  try {
    const { task_id, employee_id, notes } = req.body;
    
    if (!task_id || !employee_id) {
      return res.status(400).json({ error: 'Task ID and Employee ID are required' });
    }
    
    // Check if user has access to this task and employee
    const accessCheck = await pool.query(`
      SELECT 
        t.id as task_id, t.title, t.department_id as task_dept,
        e.id as employee_id, e.first_name, e.last_name, e.department_id as emp_dept,
        d.name as department_name
      FROM tasks t
      CROSS JOIN employees e
      LEFT JOIN departments d ON t.department_id = d.id
      WHERE t.id = $1 AND e.id = $2
      ${req.departmentFilter && req.departmentFilter.department_id ? 'AND t.department_id = $3 AND e.department_id = $3' : ''}
    `, req.departmentFilter && req.departmentFilter.department_id ? [task_id, employee_id, req.departmentFilter.department_id] : [task_id, employee_id]);
    
    if (accessCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Task or employee not found, or access denied' });
    }
    
    // Create task assignment
    const result = await pool.query(`
      INSERT INTO task_assignments (task_id, employee_id, assigned_date, notes)
      VALUES ($1, $2, CURRENT_DATE, $3)
      RETURNING *
    `, [task_id, employee_id, notes]);
    
    // Update task status to in_progress if it was pending
    await pool.query(`
      UPDATE tasks SET status = 'in_progress', updated_at = CURRENT_TIMESTAMP 
      WHERE id = $1 AND status = 'pending'
    `, [task_id]);
    
    console.log('Task assigned successfully');
    
    res.json({
      success: true,
      message: 'Task assigned successfully',
      assignment: result.rows[0]
    });
  } catch (error) {
    console.error('ERROR in assignTaskToEmployee:', error);
    handleError(res, error, 'Failed to assign task');
  }
};

// IMPORTANT: Make sure your exports include ALL functions
module.exports = { 
  getAllTasks, 
  createTask, 
  updateTaskStatus,        // ← Must be here
  assignTaskToEmployee     // ← Must be here
};