const pool = require('../config/database');
const { handleError } = require('../middleware/errorHandler');

const getDashboard = async (req, res) => {
  try {
    // Build base queries with department filtering if needed
    let employeeFilter = '';
    let toolFilter = '';
    let taskFilter = '';
    let assignmentFilter = '';
    let params = [];
    let paramIndex = 1;

    if (req.departmentFilter.department_id) {
      employeeFilter = ` AND e.department_id = $${paramIndex}`;
      toolFilter = ` WHERE t.department_id = $${paramIndex}`;
      taskFilter = ` AND tk.department_id = $${paramIndex}`;
      assignmentFilter = ` AND t.department_id = $${paramIndex}`;
      params.push(req.departmentFilter.department_id);
      paramIndex++;
    }

    // Get comprehensive dashboard data
    const dashboardQueries = await Promise.all([
      // Total and active employees
      pool.query(`
        SELECT 
          COUNT(*) as total_employees,
          COUNT(CASE WHEN e.is_active = true THEN 1 END) as active_employees,
          COUNT(CASE WHEN e.created_at >= CURRENT_DATE THEN 1 END) as new_employees_today
        FROM employees e 
        WHERE 1=1 ${employeeFilter}
      `, params),

      // Tool statistics
      pool.query(`
        SELECT 
          COUNT(*) as total_tools,
          COUNT(CASE WHEN t.status = 'available' THEN 1 END) as available_tools,
          COUNT(CASE WHEN t.status = 'assigned' THEN 1 END) as tools_in_use,
          COUNT(CASE WHEN t.status = 'maintenance' THEN 1 END) as tools_maintenance
        FROM tools t 
        ${toolFilter}
      `, toolFilter ? params : []),

      // Task statistics  
      pool.query(`
        SELECT 
          COUNT(*) as total_tasks,
          COUNT(CASE WHEN tk.status = 'pending' THEN 1 END) as pending_tasks,
          COUNT(CASE WHEN tk.status = 'completed' THEN 1 END) as completed_tasks,
          COUNT(CASE WHEN tk.status = 'in_progress' THEN 1 END) as in_progress_tasks,
          COUNT(CASE WHEN tk.created_at >= CURRENT_DATE THEN 1 END) as tasks_created_today,
          COUNT(CASE WHEN tk.status = 'completed' AND tk.updated_at >= CURRENT_DATE THEN 1 END) as tasks_completed_today
        FROM tasks tk 
        WHERE 1=1 ${taskFilter}
      `, taskFilter ? params : []),

      // Tool assignments (active)
      pool.query(`
        SELECT 
          COUNT(*) as active_tool_assignments,
          COUNT(CASE WHEN ta.assigned_date = CURRENT_DATE THEN 1 END) as assignments_today
        FROM tool_assignments ta 
        JOIN tools t ON ta.tool_id = t.id 
        WHERE ta.returned_date IS NULL ${assignmentFilter}
      `, assignmentFilter ? params : []),

      // Department productivity metrics
      pool.query(`
        SELECT 
          d.id,
          d.name as department_name,
          COUNT(DISTINCT e.id) as employee_count,
          COUNT(DISTINCT t.id) as tool_count,
          COUNT(DISTINCT tk.id) as total_task_count,
          COUNT(DISTINCT CASE WHEN tk.status = 'completed' THEN tk.id END) as completed_task_count,
          COUNT(DISTINCT CASE WHEN tk.status = 'pending' THEN tk.id END) as pending_task_count,
          COUNT(DISTINCT CASE WHEN ta.returned_date IS NULL THEN ta.id END) as active_assignments,
          -- Calculate productivity percentage
          CASE 
            WHEN COUNT(DISTINCT tk.id) > 0 THEN 
              ROUND((COUNT(DISTINCT CASE WHEN tk.status = 'completed' THEN tk.id END)::decimal / COUNT(DISTINCT tk.id)) * 100, 0)
            ELSE 0 
          END as productivity_percentage,
          -- Calculate efficiency score based on multiple factors
          CASE 
            WHEN COUNT(DISTINCT e.id) > 0 AND COUNT(DISTINCT tk.id) > 0 THEN
              ROUND((
                (COUNT(DISTINCT CASE WHEN tk.status = 'completed' THEN tk.id END)::decimal / COUNT(DISTINCT tk.id)) * 0.4 +
                (COUNT(DISTINCT CASE WHEN e.is_active = true THEN e.id END)::decimal / COUNT(DISTINCT e.id)) * 0.3 +
                (COUNT(DISTINCT CASE WHEN t.status = 'available' THEN t.id END)::decimal / GREATEST(COUNT(DISTINCT t.id), 1)) * 0.3
              ) * 100, 0)
            ELSE 0
          END as efficiency_score
        FROM departments d
        LEFT JOIN employees e ON d.id = e.department_id
        LEFT JOIN tools t ON d.id = t.department_id  
        LEFT JOIN tasks tk ON d.id = tk.department_id
        LEFT JOIN tool_assignments ta ON t.id = ta.tool_id AND ta.returned_date IS NULL
        ${req.departmentFilter.department_id ? 'WHERE d.id = $1' : ''}
        GROUP BY d.id, d.name
        ORDER BY d.name
      `, req.departmentFilter.department_id ? params : []),

      // Recent activities for live feed
      pool.query(`
        SELECT 
          'task_completed' as activity_type,
          'Task "' || tk.title || '" completed' as message,
          tk.updated_at as activity_time
        FROM tasks tk 
        WHERE tk.status = 'completed' 
          AND tk.updated_at >= CURRENT_DATE - INTERVAL '1 day'
          ${taskFilter}
        
        UNION ALL
        
        SELECT 
          'tool_assigned' as activity_type,
          'Tool "' || t.name || '" assigned to employee' as message,
          ta.created_at as activity_time
        FROM tool_assignments ta
        JOIN tools t ON ta.tool_id = t.id
        WHERE ta.assigned_date >= CURRENT_DATE - INTERVAL '1 day'
          ${assignmentFilter}
        
        UNION ALL
        
        SELECT 
          'employee_added' as activity_type,
          'New employee "' || e.first_name || ' ' || e.last_name || '" added' as message,
          e.created_at as activity_time
        FROM employees e
        WHERE e.created_at >= CURRENT_DATE - INTERVAL '1 day'
          ${employeeFilter}
        
        ORDER BY activity_time DESC
        LIMIT 10
      `, taskFilter || assignmentFilter || employeeFilter ? params : [])
    ]);

    // Extract results
    const [employeeStats, toolStats, taskStats, assignmentStats, departmentStats, recentActivities] = dashboardQueries;
    
    const employees = employeeStats.rows[0];
    const tools = toolStats.rows[0];
    const tasks = taskStats.rows[0];
    const assignments = assignmentStats.rows[0];
    const departments = departmentStats.rows;
    const activities = recentActivities.rows;

    // Calculate overall farm efficiency
    const totalTasks = parseInt(tasks.total_tasks) || 1;
    const completedTasks = parseInt(tasks.completed_tasks) || 0;
    const totalEmployees = parseInt(employees.total_employees) || 1;
    const activeEmployees = parseInt(employees.active_employees) || 0;
    const totalTools = parseInt(tools.total_tools) || 1;
    const availableTools = parseInt(tools.available_tools) || 0;

    const overallEfficiency = Math.round(
      (completedTasks / totalTasks) * 0.4 +
      (activeEmployees / totalEmployees) * 0.3 +
      (availableTools / totalTools) * 0.3
    ) * 100;

    // Build enhanced dashboard response
    const dashboardData = {
      // Basic stats
      total_employees: parseInt(employees.total_employees) || 0,
      active_employees: parseInt(employees.active_employees) || 0,
      new_employees_today: parseInt(employees.new_employees_today) || 0,
      
      total_tools: parseInt(tools.total_tools) || 0,
      available_tools: parseInt(tools.available_tools) || 0,
      tools_in_use: parseInt(tools.tools_in_use) || 0,
      tools_maintenance: parseInt(tools.tools_maintenance) || 0,
      
      total_tasks: parseInt(tasks.total_tasks) || 0,
      pending_tasks: parseInt(tasks.pending_tasks) || 0,
      completed_tasks: parseInt(tasks.completed_tasks) || 0,
      in_progress_tasks: parseInt(tasks.in_progress_tasks) || 0,
      tasks_created_today: parseInt(tasks.tasks_created_today) || 0,
      tasks_completed_today: parseInt(tasks.tasks_completed_today) || 0,
      
      active_tool_assignments: parseInt(assignments.active_tool_assignments) || 0,
      assignments_today: parseInt(assignments.assignments_today) || 0,
      
      // Enhanced metrics for dashboard
      productivity: {
        cropProduction: departments.find(d => d.department_name === 'Crop Production')?.productivity_percentage || 0,
        livestock: departments.find(d => d.department_name === 'Livestock')?.productivity_percentage || 0,
        equipment: departments.find(d => d.department_name === 'Equipment Maintenance')?.productivity_percentage || 0,
        administration: departments.find(d => d.department_name === 'Administration')?.productivity_percentage || 0
      },
      
      efficiency: {
        cropProduction: departments.find(d => d.department_name === 'Crop Production')?.efficiency_score || 0,
        livestock: departments.find(d => d.department_name === 'Livestock')?.efficiency_score || 0,
        equipment: departments.find(d => d.department_name === 'Equipment Maintenance')?.efficiency_score || 0,
        administration: departments.find(d => d.department_name === 'Administration')?.efficiency_score || 0
      },
      
      todayStats: {
        tasksCompleted: parseInt(tasks.tasks_completed_today) || 0,
        tasksCreated: parseInt(tasks.tasks_created_today) || 0,
        toolsInUse: parseInt(tools.tools_in_use) || 0,
        employeesActive: parseInt(employees.active_employees) || 0,
        newEmployees: parseInt(employees.new_employees_today) || 0,
        newAssignments: parseInt(assignments.assignments_today) || 0,
        overallEfficiency: overallEfficiency
      },
      
      // Department breakdown
      department_breakdown: departments,
      
      // Recent activities
      recent_activities: activities.map(activity => ({
        type: activity.activity_type,
        message: activity.message,
        time: activity.activity_time,
        timeAgo: getTimeAgo(activity.activity_time)
      })),
      
      // Performance trends (last 7 days)
      trends: {
        taskCompletionTrend: await getTaskCompletionTrend(req.departmentFilter.department_id),
        employeeProductivityTrend: await getEmployeeProductivityTrend(req.departmentFilter.department_id),
        toolUsageTrend: await getToolUsageTrend(req.departmentFilter.department_id)
      }
    };
    
    res.json(dashboardData);
  } catch (error) {
    handleError(res, error, 'Failed to fetch dashboard data');
  }
};

// Helper function to get task completion trend
const getTaskCompletionTrend = async (departmentId) => {
  try {
    const query = `
      SELECT 
        DATE(updated_at) as date,
        COUNT(*) as completed_tasks
      FROM tasks 
      WHERE status = 'completed' 
        AND updated_at >= CURRENT_DATE - INTERVAL '7 days'
        ${departmentId ? 'AND department_id = $1' : ''}
      GROUP BY DATE(updated_at)
      ORDER BY date
    `;
    
    const result = await pool.query(query, departmentId ? [departmentId] : []);
    return result.rows;
  } catch (error) {
    console.error('Error getting task completion trend:', error);
    return [];
  }
};

// Helper function to get employee productivity trend
const getEmployeeProductivityTrend = async (departmentId) => {
  try {
    const query = `
      SELECT 
        DATE(ta.created_at) as date,
        COUNT(DISTINCT ta.employee_id) as active_employees,
        COUNT(*) as total_assignments
      FROM task_assignments ta
      JOIN employees e ON ta.employee_id = e.id
      WHERE ta.created_at >= CURRENT_DATE - INTERVAL '7 days'
        ${departmentId ? 'AND e.department_id = $1' : ''}
      GROUP BY DATE(ta.created_at)
      ORDER BY date
    `;
    
    const result = await pool.query(query, departmentId ? [departmentId] : []);
    return result.rows;
  } catch (error) {
    console.error('Error getting employee productivity trend:', error);
    return [];
  }
};

// Helper function to get tool usage trend
const getToolUsageTrend = async (departmentId) => {
  try {
    const query = `
      SELECT 
        DATE(assigned_date) as date,
        COUNT(*) as tool_assignments
      FROM tool_assignments ta
      JOIN tools t ON ta.tool_id = t.id
      WHERE assigned_date >= CURRENT_DATE - INTERVAL '7 days'
        ${departmentId ? 'AND t.department_id = $1' : ''}
      GROUP BY DATE(assigned_date)
      ORDER BY date
    `;
    
    const result = await pool.query(query, departmentId ? [departmentId] : []);
    return result.rows;
  } catch (error) {
    console.error('Error getting tool usage trend:', error);
    return [];
  }
};

// Helper function to format time ago
const getTimeAgo = (date) => {
  const now = new Date();
  const past = new Date(date);
  const diffInMinutes = Math.floor((now - past) / (1000 * 60));
  
  if (diffInMinutes < 1) return 'Just now';
  if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
  
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) return `${diffInHours}h ago`;
  
  const diffInDays = Math.floor(diffInHours / 24);
  return `${diffInDays}d ago`;
};

// Keep existing functions
const getDepartmentReports = async (req, res) => {
  try {
    if (req.user.role !== 'farm_owner') {
      return res.status(403).json({ error: 'Only farm owner can access department reports' });
    }
    
    const departmentReports = await pool.query(`
      SELECT 
        d.id,
        d.name as department_name,
        d.description,
        COUNT(DISTINCT e.id) as total_employees,
        COUNT(DISTINCT CASE WHEN e.is_active = true THEN e.id END) as active_employees,
        COUNT(DISTINCT t.id) as total_tools,
        COUNT(DISTINCT CASE WHEN t.status = 'available' THEN t.id END) as available_tools,
        COUNT(DISTINCT CASE WHEN t.status = 'assigned' THEN t.id END) as assigned_tools,
        COUNT(DISTINCT tk.id) as total_tasks,
        COUNT(DISTINCT CASE WHEN tk.status = 'pending' THEN tk.id END) as pending_tasks,
        COUNT(DISTINCT CASE WHEN tk.status = 'completed' THEN tk.id END) as completed_tasks,
        -- Productivity score
        CASE 
          WHEN COUNT(DISTINCT tk.id) > 0 THEN 
            ROUND((COUNT(DISTINCT CASE WHEN tk.status = 'completed' THEN tk.id END)::decimal / COUNT(DISTINCT tk.id)) * 100, 2)
          ELSE 0 
        END as productivity_score
      FROM departments d
      LEFT JOIN employees e ON d.id = e.department_id
      LEFT JOIN tools t ON d.id = t.department_id
      LEFT JOIN tasks tk ON d.id = tk.department_id
      GROUP BY d.id, d.name, d.description
      ORDER BY d.name
    `);
    
    res.json(departmentReports.rows);
  } catch (error) {
    handleError(res, error, 'Failed to fetch department reports');
  }
};

const getDepartments = async (req, res) => {
  try {
    if (req.user.role !== 'farm_owner') {
      return res.status(403).json({ error: 'Only farm owner can view all departments' });
    }
    
    const result = await pool.query('SELECT * FROM departments ORDER BY name');
    res.json(result.rows);
  } catch (error) {
    handleError(res, error, 'Failed to fetch departments');
  }
};

module.exports = { getDashboard, getDepartmentReports, getDepartments };