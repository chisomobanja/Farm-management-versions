import React, { useState, useEffect } from 'react';
import { 
  User, Users, Wrench, CheckSquare, BarChart3, LogOut, Plus, Edit, Trash2, 
  Calendar, MapPin, Phone, Mail, AlertCircle, CheckCircle, Clock, Settings, 
  Home, TrendingUp, Activity, Target, Award, ArrowUp, ArrowDown, Cloud, Sun, 
  CloudRain, Wind, Thermometer, Droplets, Zap, Wifi
} from 'lucide-react';

// API Configuration
const API_BASE_URL = 'http://localhost:5000'; // Adjust this to your backend URL

// Updated API Helper Functions with better error handling
const api = {
  // Auth endpoints
  login: async (credentials) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(credentials)
      });
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Login API error:', error);
      return { error: 'Network error during login' };
    }
  },
  
  // Dashboard endpoints
  getDashboard: async (token) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/dashboard`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Dashboard API error:', error);
      return { error: 'Failed to load dashboard' };
    }
  },
  
  // Employee endpoints
  getEmployees: async (token) => {
    try {
      console.log('Fetching employees from:', `${API_BASE_URL}/api/employees`);
      console.log('Using token:', token ? 'Present' : 'Missing');
      
      const response = await fetch(`${API_BASE_URL}/api/employees`, {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('API error response:', errorData);
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('Employees data received:', data);
      
      // Ensure we always return an array
      if (Array.isArray(data)) {
        return data;
      } else {
        console.warn('Expected array but got:', typeof data, data);
        return [];
      }
    } catch (error) {
      console.error('Get employees API error:', error);
      // Return error object that the component can handle
      return { error: error.message || 'Failed to fetch employees' };
    }
  },
  
  createEmployee: async (token, employeeData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/employees`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify(employeeData)
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { error: data.error || `HTTP error! status: ${response.status}` };
      }
      
      return data;
    } catch (error) {
      console.error('Create employee API error:', error);
      return { error: 'Failed to create employee' };
    }
  },
  
  deleteEmployee: async (token, id) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/employees/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || `HTTP error! status: ${response.status}`);
      }
      
      return data;
    } catch (error) {
      console.error('Delete employee API error:', error);
      throw error;
    }
  },
  
  // Tool endpoints
  getTools: async (token) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/tools`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error('Get tools API error:', error);
      return { error: error.message || 'Failed to fetch tools' };
    }
  },
  
  createTool: async (token, toolData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/tools`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify(toolData)
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { error: data.error || `HTTP error! status: ${response.status}` };
      }
      
      return data;
    } catch (error) {
      console.error('Create tool API error:', error);
      return { error: 'Failed to create tool' };
    }
  },
  
  // Task endpoints
  getTasks: async (token) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/tasks`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error('Get tasks API error:', error);
      return { error: error.message || 'Failed to fetch tasks' };
    }
  },
  
  createTask: async (token, taskData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/tasks`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify(taskData)
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { error: data.error || `HTTP error! status: ${response.status}` };
      }
      
      return data;
    } catch (error) {
      console.error('Create task API error:', error);
      return { error: 'Failed to create task' };
    }
  },
  
  getDepartments: async (token) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/dashboard/departments`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error('Get departments API error:', error);
      return [];
    }
  },
  
  // Assignment endpoints
  assignTool: async (token, assignmentData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/assignments/tools`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify(assignmentData)
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { error: data.error || `HTTP error! status: ${response.status}` };
      }
      
      return data;
    } catch (error) {
      console.error('Assign tool API error:', error);
      return { error: 'Failed to assign tool' };
    }
  },
  
  assignTask: async (token, assignmentData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/assignments/tasks`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify(assignmentData)
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { error: data.error || `HTTP error! status: ${response.status}` };
      }
      
      return data;
    } catch (error) {
      console.error('Assign task API error:', error);
      return { error: 'Failed to assign task' };
    }
  },
  
  getEmployeeTools: async (token, employeeId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/assignments/employee/${employeeId}/tools`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    } catch (error) {
      console.error('Get employee tools API error:', error);
      return [];
    }
  },
  
  returnTool: async (token, assignmentId, notes) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/assignments/tools/${assignmentId}/return`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({ notes })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        return { error: data.error || `HTTP error! status: ${response.status}` };
      }
      
      return data;
    } catch (error) {
      console.error('Return tool API error:', error);
      return { error: 'Failed to return tool' };
    }
  }
};

// Animated Progress Ring Component
const ProgressRing = ({ progress, size = 120, strokeWidth = 8, color = '#10b981' }) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const strokeDasharray = `${circumference} ${circumference}`;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="relative">
      <svg
        className="transform -rotate-90"
        width={size}
        height={size}
      >
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#e5e7eb"
          strokeWidth={strokeWidth}
          fill="transparent"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeDasharray={strokeDasharray}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-2xl font-bold text-gray-700">{progress}%</span>
      </div>
    </div>
  );
};

// Animated Counter Component
const AnimatedCounter = ({ value, duration = 2000 }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const increment = value / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);

    return () => clearInterval(timer);
  }, [value, duration]);

  return <span>{count}</span>;
};

// Racing Bar Component
const RacingBar = ({ label, value, maxValue, color, icon: Icon, delay = 0 }) => {
  const [animatedValue, setAnimatedValue] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedValue(value);
    }, delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  const percentage = (animatedValue / maxValue) * 100;

  return (
    <div className="mb-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2">
          <Icon className={`w-4 h-4 ${color}`} />
          <span className="text-sm font-medium text-gray-700">{label}</span>
        </div>
        <span className="text-sm font-bold text-gray-900">{animatedValue}</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
        <div
          className={`h-3 rounded-full bg-gradient-to-r transition-all duration-2000 ease-out ${color.replace('text-', 'from-')}-400 ${color.replace('text-', 'to-')}-600`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

// Enhanced Weather Widget Component
const EnhancedWeatherWidget = () => {
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    setTimeout(() => {
      const conditions = [
        {
          temp: 24,
          condition: 'Sunny',
          icon: '☀️',
          humidity: 45,
          wind: 2.5,
          advice: 'Perfect weather for field work and planting',
          color: 'from-yellow-400 to-orange-500'
        },
        {
          temp: 18,
          condition: 'Partly Cloudy',
          icon: '⛅',
          humidity: 65,
          wind: 3.2,
          advice: 'Good conditions for outdoor tasks',
          color: 'from-gray-400 to-blue-500'
        },
        {
          temp: 15,
          condition: 'Light Rain',
          icon: '🌧️',
          humidity: 85,
          wind: 4.1,
          advice: 'Indoor maintenance tasks recommended',
          color: 'from-blue-400 to-blue-600'
        }
      ];
      
      const randomWeather = conditions[Math.floor(Math.random() * conditions.length)];
      setWeather({
        location: 'Lusaka, ZM',
        ...randomWeather
      });
    }, 500);
  }, []);

  if (!weather) {
    return (
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-6 rounded-xl text-white animate-pulse">
        <div className="h-4 bg-blue-400 rounded mb-2"></div>
        <div className="h-8 bg-blue-400 rounded mb-2"></div>
        <div className="h-4 bg-blue-400 rounded"></div>
      </div>
    );
  }

  return (
    <div className={`bg-gradient-to-br ${weather.color} text-white p-6 rounded-xl shadow-lg transform transition-all duration-500 hover:scale-105`}>
      <div className="flex justify-between items-start mb-4">
        <div>
          <div className="flex items-center space-x-2 mb-2">
            <MapPin className="w-4 h-4" />
            <h4 className="font-medium text-sm opacity-90">{weather.location}</h4>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs">LIVE</span>
            </div>
          </div>
          <p className="text-3xl font-bold">{weather.temp}°C</p>
          <p className="text-sm opacity-90">{weather.condition}</p>
        </div>
        <div className="text-4xl">{weather.icon}</div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
        <div className="flex items-center space-x-2">
          <Droplets className="w-4 h-4" />
          <span>{weather.humidity}%</span>
        </div>
        <div className="flex items-center space-x-2">
          <Wind className="w-4 h-4" />
          <span>{weather.wind} m/s</span>
        </div>
      </div>
      
      <div className="pt-4 border-t border-white/20">
        <div className="flex items-center space-x-2">
          <Target className="w-4 h-4" />
          <p className="text-sm font-medium">{weather.advice}</p>
        </div>
      </div>
    </div>
  );
};


// Updated Live Activity Feed Component that uses real data
const LiveActivity = ({ user, dashboardData }) => {
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    if (dashboardData && dashboardData.recent_activities) {
      // Use real activities from the database
      const realActivities = dashboardData.recent_activities.map((activity, index) => ({
        id: `real-${index}`,
        type: activity.type,
        message: activity.message,
        time: activity.timeAgo,
        icon: getActivityIcon(activity.type),
        color: getActivityColor(activity.type)
      }));

      setActivities(realActivities);
    }

    // Still simulate some real-time updates for demo purposes
    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        const systemActivities = [
          { type: 'system_update', message: 'Dashboard data refreshed', icon: CheckCircle, color: 'text-green-500' },
          { type: 'weather_update', message: 'Weather conditions updated', icon: Sun, color: 'text-yellow-500' },
          { type: 'system_status', message: 'All systems operational', icon: CheckCircle, color: 'text-green-500' }
        ];
        
        const randomActivity = systemActivities[Math.floor(Math.random() * systemActivities.length)];
        const newActivity = {
          id: `system-${Date.now()}`,
          ...randomActivity,
          time: 'Just now'
        };
        
        setActivities(prev => [newActivity, ...prev.slice(0, 4)]);
      }
    }, 45000);

    return () => clearInterval(interval);
  }, [dashboardData]);

  const getActivityIcon = (type) => {
    const iconMap = {
      'task_completed': CheckCircle,
      'tool_assigned': Wrench,
      'employee_added': Users,
      'system_update': Activity,
      'weather_update': Sun,
      'system_status': CheckCircle
    };
    return iconMap[type] || Activity;
  };

  const getActivityColor = (type) => {
    const colorMap = {
      'task_completed': 'text-green-500',
      'tool_assigned': 'text-blue-500',
      'employee_added': 'text-purple-500',
      'system_update': 'text-blue-500',
      'weather_update': 'text-yellow-500',
      'system_status': 'text-green-500'
    };
    return colorMap[type] || 'text-gray-500';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center space-x-2">
          <Activity className="w-5 h-5 text-green-500" />
          <span>Live Activity</span>
        </h3>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-green-600 font-medium">LIVE</span>
        </div>
      </div>
      
      <div className="space-y-4 max-h-64 overflow-y-auto">
        {activities.length === 0 ? (
          <div className="text-center text-gray-500 py-4">
            <Activity className="w-8 h-8 mx-auto mb-2 text-gray-400" />
            <p className="text-sm">No recent activity</p>
          </div>
        ) : (
          activities.map((activity, index) => {
            const Icon = activity.icon;
            return (
              <div 
                key={activity.id} 
                className={`flex items-start space-x-3 p-3 rounded-lg transition-all duration-500 ${
                  index === 0 ? 'bg-green-50 border border-green-200 scale-105' : 'hover:bg-gray-50'
                }`}
              >
                <Icon className={`w-5 h-5 ${activity.color} mt-0.5 ${index === 0 ? 'animate-bounce' : ''}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

// Updated Impressive Dashboard Component with real data
const ImpressiveDashboard = ({ dashboardData, user, onRefresh }) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    // Update time every second
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timeInterval);
  }, []);

  if (!dashboardData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-4 border-green-500 mx-auto mb-8"></div>
          <h2 className="text-2xl font-bold text-gray-700 mb-2">Initializing Farm Command Center</h2>
          <p className="text-gray-500">Loading real-time data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2 bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
              🚀 Farm Command Center
            </h1>
            <div className="flex items-center space-x-6 text-sm text-gray-600">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>{currentTime.toLocaleDateString()}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span className="font-mono">{currentTime.toLocaleTimeString()}</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-green-600 font-medium">All Systems Operational</span>
              </div>
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>Welcome back, {user.username}!</span>
              </div>
            </div>
          </div>
          
          {/* Real-time stats */}
          <div className="flex items-center space-x-4">
            <div className="bg-white/90 backdrop-blur rounded-xl p-4 shadow-lg">
              <div className="text-2xl font-bold text-green-600">
                <AnimatedCounter value={dashboardData.todayStats?.tasksCompleted || 0} />
              </div>
              <div className="text-sm text-gray-600">Tasks Completed Today</div>
            </div>
            <div className="bg-white/90 backdrop-blur rounded-xl p-4 shadow-lg">
              <div className="text-2xl font-bold text-blue-600">
                <AnimatedCounter value={dashboardData.todayStats?.employeesActive || 0} />
              </div>
              <div className="text-sm text-gray-600">Active Employees</div>
            </div>
            <button
              onClick={onRefresh}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2 transition-all duration-200 hover:scale-105"
            >
              <Activity className="w-4 h-4" />
              <span>Refresh</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Stats Grid with REAL DATA */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[
          { 
            label: 'Active Employees', 
            value: dashboardData.active_employees || 0, 
            total: dashboardData.total_employees || 1,
            icon: Users, 
            color: 'from-blue-500 to-blue-600',
            change: `+${dashboardData.new_employees_today || 0} today`
          },
          { 
            label: 'Tools in Use', 
            value: dashboardData.tools_in_use || 0, 
            total: dashboardData.total_tools || 1,
            icon: Wrench, 
            color: 'from-green-500 to-green-600',
            change: `${dashboardData.available_tools || 0} available`
          },
          { 
            label: 'Pending Tasks', 
            value: dashboardData.pending_tasks || 0, 
            total: dashboardData.total_tasks || 1,
            icon: CheckSquare, 
            color: 'from-yellow-500 to-yellow-600',
            change: `${dashboardData.completed_tasks || 0} completed`
          },
          { 
            label: 'Farm Efficiency', 
            value: dashboardData.todayStats?.overallEfficiency || 0, 
            total: 100,
            icon: TrendingUp, 
            color: 'from-purple-500 to-purple-600',
            change: `${dashboardData.tasks_completed_today || 0} tasks done today`
          }
        ].map((stat, index) => {
          const Icon = stat.icon;
          const percentage = Math.min(100, (stat.value / stat.total) * 100);
          
          return (
            <div key={index} className="bg-white rounded-xl shadow-lg p-6 transform transition-all duration-300 hover:scale-105 hover:shadow-xl border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-xl bg-gradient-to-r ${stat.color} shadow-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-gray-900">
                    <AnimatedCounter value={stat.value} />
                    {stat.label === 'Farm Efficiency' && '%'}
                  </div>
                  <div className="text-sm text-gray-500">of {stat.total}</div>
                </div>
              </div>
              <div className="mb-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-600 font-medium">{stat.label}</span>
                  <span className="font-bold text-gray-800">{Math.round(percentage)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                  <div 
                    className={`h-3 rounded-full bg-gradient-to-r ${stat.color} transition-all duration-2000 ease-out shadow-inner`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
              <div className="flex items-center text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                <span className="text-gray-600 font-medium">{stat.change}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Middle Section with REAL DATA */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Weather */}
        <div>
          <EnhancedWeatherWidget />
        </div>

        {/* Department Performance with REAL DATA */}
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-800 mb-6 flex items-center space-x-2">
            <Target className="w-5 h-5 text-green-500" />
            <span>Department Performance</span>
          </h3>
          <div className="grid grid-cols-2 gap-6">
            {[
              { 
                label: 'Crops', 
                progress: dashboardData.productivity?.cropProduction || 0, 
                color: '#10b981',
                efficiency: dashboardData.efficiency?.cropProduction || 0
              },
              { 
                label: 'Livestock', 
                progress: dashboardData.productivity?.livestock || 0, 
                color: '#3b82f6',
                efficiency: dashboardData.efficiency?.livestock || 0
              },
              { 
                label: 'Equipment', 
                progress: dashboardData.productivity?.equipment || 0, 
                color: '#8b5cf6',
                efficiency: dashboardData.efficiency?.equipment || 0
              },
              { 
                label: 'Admin', 
                progress: dashboardData.productivity?.administration || 0, 
                color: '#f59e0b',
                efficiency: dashboardData.efficiency?.administration || 0
              }
            ].map((dept, index) => (
              <div key={index} className="text-center group">
                <div className="transform transition-all duration-300 group-hover:scale-110">
                  <ProgressRing 
                    progress={Math.max(dept.progress, dept.efficiency)} 
                    size={90} 
                    color={dept.color} 
                  />
                </div>
                <p className="text-sm font-semibold text-gray-700 mt-3">{dept.label}</p>
                <p className="text-xs text-gray-500">
                  {dept.progress > 0 ? `${dept.progress}% tasks` : 'No data'}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Live Activity with REAL DATA */}
        <div>
          <LiveActivity user={user} dashboardData={dashboardData} />
        </div>
      </div>

      {/* Department Racing Bars with REAL DATA */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center space-x-2">
            <Award className="w-5 h-5 text-yellow-500" />
            <span>Department Performance Race</span>
          </h3>
          <div className="text-sm text-gray-500">Live Competition</div>
        </div>
        
        <div className="space-y-4">
          {dashboardData.department_breakdown && dashboardData.department_breakdown.length > 0 ? (
            dashboardData.department_breakdown
              .sort((a, b) => (b.productivity_percentage || 0) - (a.productivity_percentage || 0))
              .map((dept, index) => (
                <RacingBar 
                  key={dept.id}
                  label={dept.department_name} 
                  value={dept.productivity_percentage || 0} 
                  maxValue={100}
                  color={index === 0 ? 'text-green-500' : index === 1 ? 'text-blue-500' : index === 2 ? 'text-purple-500' : 'text-yellow-500'}
                  icon={index === 0 ? Award : index === 1 ? TrendingUp : Users}
                  delay={index * 300}
                />
              ))
          ) : (
            // Fallback if no department data
            [
              { 
                label: "Equipment Maintenance", 
                value: dashboardData.productivity?.equipment || 0,
                color: "text-purple-500",
                icon: Wrench,
                delay: 0
              },
              { 
                label: "Livestock Management", 
                value: dashboardData.productivity?.livestock || 0,
                color: "text-blue-500",
                icon: Users,
                delay: 300
              },
              { 
                label: "Crop Production", 
                value: dashboardData.productivity?.cropProduction || 0,
                color: "text-green-500",
                icon: TrendingUp,
                delay: 600
              },
              { 
                label: "Administration", 
                value: dashboardData.productivity?.administration || 0,
                color: "text-yellow-500",
                icon: CheckSquare,
                delay: 900
              }
            ].map((dept, index) => (
              <RacingBar 
                key={index}
                label={dept.label} 
                value={dept.value} 
                maxValue={100}
                color={dept.color}
                icon={dept.icon}
                delay={dept.delay}
              />
            ))
          )}
        </div>
        
        {/* Winner Badge with REAL DATA */}
        {dashboardData.department_breakdown && dashboardData.department_breakdown.length > 0 && (
          <div className="mt-6 p-4 bg-gradient-to-r from-yellow-100 to-yellow-200 rounded-lg border border-yellow-300">
            <div className="flex items-center justify-center space-x-2">
              <Award className="w-5 h-5 text-yellow-600" />
              <span className="font-semibold text-yellow-800">
                🏆 {dashboardData.department_breakdown
                  .sort((a, b) => (b.productivity_percentage || 0) - (a.productivity_percentage || 0))[0]?.department_name || 'No leader'} leads today!
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Real-time Statistics Summary */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
          <h4 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <CheckCircle className="w-5 h-5 text-green-500" />
            <span>Today's Achievements</span>
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Tasks Completed:</span>
              <span className="font-bold text-green-600">{dashboardData.tasks_completed_today || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">New Assignments:</span>
              <span className="font-bold text-blue-600">{dashboardData.assignments_today || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">New Employees:</span>
              <span className="font-bold text-purple-600">{dashboardData.new_employees_today || 0}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
          <h4 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <Wrench className="w-5 h-5 text-blue-500" />
            <span>Tool Status</span>
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Available:</span>
              <span className="font-bold text-green-600">{dashboardData.available_tools || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">In Use:</span>
              <span className="font-bold text-yellow-600">{dashboardData.tools_in_use || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Maintenance:</span>
              <span className="font-bold text-red-600">{dashboardData.tools_maintenance || 0}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
          <h4 className="font-semibold text-gray-800 mb-4 flex items-center space-x-2">
            <Users className="w-5 h-5 text-purple-500" />
            <span>Workforce Status</span>
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Total Employees:</span>
              <span className="font-bold text-blue-600">{dashboardData.total_employees || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Active Today:</span>
              <span className="font-bold text-green-600">{dashboardData.active_employees || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Efficiency:</span>
              <span className="font-bold text-purple-600">
                {dashboardData.total_employees > 0 
                  ? Math.round((dashboardData.active_employees / dashboardData.total_employees) * 100)
                  : 0}%
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
// Login Component
const Login = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const result = await api.login(credentials);
      if (result.error) {
        setError(result.error);
      } else {
        onLogin(result.token, result.user);
      }
    } catch (error) {
      setError('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-400 to-blue-600 flex items-center justify-center">
      <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-md">
        <div className="text-center mb-8">
          <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Home className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Farm Management</h1>
          <p className="text-gray-600">Sign in to your account</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">
              {error}
            </div>
          )}
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
            <input
              type="text"
              value={credentials.username}
              onChange={(e) => setCredentials({...credentials, username: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
            <input
              type="password"
              value={credentials.password}
              onChange={(e) => setCredentials({...credentials, password: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              required
            />
          </div>
          
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 focus:ring-4 focus:ring-green-200 transition-colors disabled:opacity-50"
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
};

// Updated Sidebar Navigation
const Sidebar = ({ activeTab, setActiveTab, user, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'reports', label: 'Reports', icon: TrendingUp },
    { id: 'activity', label: 'Activity', icon: Activity },
    { id: 'employees', label: 'Employees', icon: Users },
    { id: 'tools', label: 'Tools', icon: Wrench },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    { id: 'profile', label: 'Profile', icon: User }
  ];

  return (
    <div className="bg-gray-900 text-white w-64 min-h-screen flex flex-col">
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <Home className="w-8 h-8 text-green-400" />
          <h1 className="text-xl font-bold">Farm Manager</h1>
        </div>
      </div>
      
      {/* Weather Widget */}
      <div className="px-4 mb-4">
        <EnhancedWeatherWidget />
      </div>
      
      <nav className="flex-1 px-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                activeTab === item.id 
                  ? 'bg-green-600 text-white' 
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
            <User className="w-6 h-6" />
          </div>
          <div>
            <p className="font-medium">{user.username}</p>
            <p className="text-sm text-gray-400 capitalize">{user.role.replace('_', ' ')}</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center space-x-3 px-4 py-2 text-red-400 hover:bg-gray-800 rounded-lg transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

// Enhanced Dashboard Component that uses real data
const Dashboard = ({ token, user }) => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const loadDashboard = async () => {
    try {
      console.log('Loading real dashboard data...');
      const data = await api.getDashboard(token);
      
      if (data.error) {
        console.error('Dashboard API error:', data.error);
        return;
      }

      console.log('Real dashboard data received:', data);
      
      // Use the real data directly - no more fake calculations!
      setDashboardData(data);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Failed to load dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
    
    // Auto-refresh every 30 seconds to show live updates
    const interval = setInterval(loadDashboard, 30000);
    
    return () => clearInterval(interval);
  }, [token]);

  // Manual refresh function
  const handleRefresh = () => {
    setLoading(true);
    loadDashboard();
  };

  if (loading && !dashboardData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-4 border-green-500 mx-auto mb-8"></div>
          <h2 className="text-2xl font-bold text-gray-700 mb-2">Loading Farm Command Center</h2>
          <p className="text-gray-500">Gathering real-time farm data...</p>
        </div>
      </div>
    );
  }

  return <ImpressiveDashboard dashboardData={dashboardData} user={user} onRefresh={handleRefresh} />;
};

// Simple Reports Component
const Reports = ({ token, user }) => {
  const [loading, setLoading] = useState(true);
  const [reportData, setReportData] = useState(null);

  useEffect(() => {
    // Simulate loading reports
    setTimeout(() => {
      setReportData({
        efficiency: 85,
        taskCompletion: 92,
        toolUsage: 78,
        productivity: 88
      });
      setLoading(false);
    }, 1500);
  }, []);

  if (loading) {
    return <div className="p-6">Loading reports...</div>;
  }

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Reports & Analytics</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[
          { label: 'Farm Efficiency', value: `${reportData.efficiency}%`, color: 'bg-blue-500' },
          { label: 'Task Completion', value: `${reportData.taskCompletion}%`, color: 'bg-green-500' },
          { label: 'Tool Usage', value: `${reportData.toolUsage}%`, color: 'bg-yellow-500' },
          { label: 'Productivity', value: `${reportData.productivity}%`, color: 'bg-purple-500' }
        ].map((metric, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{metric.label}</p>
                <p className="text-3xl font-bold text-gray-900">{metric.value}</p>
              </div>
              <div className={`${metric.color} p-3 rounded-lg`}>
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md text-center">
        <TrendingUp className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-700 mb-2">Advanced Analytics</h3>
        <p className="text-gray-600">Detailed charts and insights coming soon!</p>
      </div>
    </div>
  );
};

// Activity Page Component
const ActivityPage = ({ user }) => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Activity Feed</h1>
      <div className="max-w-2xl">
        <LiveActivity user={user} />
      </div>
    </div>
  );
};

// Employee Management Component - Fixed Version
const EmployeeManagement = ({ token, user }) => {
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [newEmployee, setNewEmployee] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    position: '',
    department_id: ''
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        setError('');
        
        console.log('Loading employees data...');
        
        const [employeesResponse, departmentsResponse] = await Promise.allSettled([
          api.getEmployees(token),
          user.role === 'farm_owner' ? api.getDepartments(token) : Promise.resolve([])
        ]);

        console.log('Employees response:', employeesResponse);
        console.log('Departments response:', departmentsResponse);

        // Handle employees data
        if (employeesResponse.status === 'fulfilled') {
          const employeesData = employeesResponse.value;
          if (Array.isArray(employeesData)) {
            setEmployees(employeesData);
          } else if (employeesData && employeesData.error) {
            setError(`Failed to load employees: ${employeesData.error}`);
            setEmployees([]);
          } else {
            console.warn('Unexpected employees data format:', employeesData);
            setEmployees([]);
          }
        } else {
          console.error('Failed to fetch employees:', employeesResponse.reason);
          setError('Failed to load employees');
          setEmployees([]);
        }

        // Handle departments data
        if (departmentsResponse.status === 'fulfilled') {
          const departmentsData = departmentsResponse.value;
          if (Array.isArray(departmentsData)) {
            setDepartments(departmentsData);
          } else {
            setDepartments([]);
          }
        } else {
          console.error('Failed to fetch departments:', departmentsResponse.reason);
          setDepartments([]);
        }

      } catch (error) {
        console.error('Failed to load data:', error);
        setError('Failed to load data');
        setEmployees([]);
        setDepartments([]);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [token, user.role]);

  const handleAddEmployee = async (e) => {
    e.preventDefault();
    try {
      // If user is supervisor, automatically use their department_id
      const employeeData = {
        ...newEmployee,
        department_id: user.role === 'supervisor' ? user.department_id : newEmployee.department_id
      };
      
      const result = await api.createEmployee(token, employeeData);
      if (result && result.error) {
        alert(result.error);
      } else if (result) {
        setEmployees([result, ...employees]);
        setNewEmployee({
          first_name: '',
          last_name: '',
          email: '',
          phone: '',
          position: '',
          department_id: ''
        });
        setShowAddForm(false);
      } else {
        alert('Failed to add employee - no response');
      }
    } catch (error) {
      console.error('Error adding employee:', error);
      alert('Failed to add employee');
    }
  };

  const handleDeleteEmployee = async (id) => {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      try {
        await api.deleteEmployee(token, id);
        setEmployees(employees.filter(emp => emp.id !== id));
      } catch (error) {
        console.error('Error deleting employee:', error);
        alert('Failed to delete employee');
      }
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-500"></div>
        </div>
        <p className="text-center mt-4">Loading employees...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error Loading Employees</h3>
              <div className="mt-2 text-sm text-red-700">
                <p>{error}</p>
              </div>
              <div className="mt-4">
                <button
                  onClick={() => window.location.reload()}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
                >
                  Retry
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Employee Management</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Add Employee</span>
        </button>
      </div>

      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New Employee</h2>
            <form onSubmit={handleAddEmployee} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                  <input
                    type="text"
                    value={newEmployee.first_name}
                    onChange={(e) => setNewEmployee({...newEmployee, first_name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                  <input
                    type="text"
                    value={newEmployee.last_name}
                    onChange={(e) => setNewEmployee({...newEmployee, last_name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  value={newEmployee.email}
                  onChange={(e) => setNewEmployee({...newEmployee, email: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="tel"
                  value={newEmployee.phone}
                  onChange={(e) => setNewEmployee({...newEmployee, phone: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Position</label>
                <input
                  type="text"
                  value={newEmployee.position}
                  onChange={(e) => setNewEmployee({...newEmployee, position: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              {/* Only show department selection for farm owners */}
              {user.role === 'farm_owner' && departments.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <select
                    value={newEmployee.department_id}
                    onChange={(e) => setNewEmployee({...newEmployee, department_id: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select Department</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                </div>
              )}
              
              {/* Show current department for supervisors */}
              {user.role === 'supervisor' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <div className="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-gray-700">
                    {user.department_name || 'Your Department'}
                  </div>
                </div>
              )}
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700"
                >
                  Add Employee
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {employees.length === 0 ? (
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-700 mb-2">No Employees Found</h3>
          <p className="text-gray-600">Get started by adding your first employee.</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Name</th>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Email</th>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Position</th>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Department</th>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((employee, index) => (
                <tr key={employee.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <User className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">
                          {employee.first_name} {employee.last_name}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-gray-600">{employee.email}</td>
                  <td className="py-4 px-6 text-gray-600">{employee.position || '-'}</td>
                  <td className="py-4 px-6 text-gray-600">{employee.department_name || '-'}</td>
                  <td className="py-4 px-6">
                    <button
                      onClick={() => handleDeleteEmployee(employee.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// Tool Management Component
const ToolManagement = ({ token, user }) => {
  const [tools, setTools] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newTool, setNewTool] = useState({
    name: '',
    type: '',
    description: '',
    serial_number: '',
    purchase_date: '',
    department_id: ''
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        const [toolsData, departmentsData] = await Promise.all([
          api.getTools(token),
          user.role === 'farm_owner' ? api.getDepartments(token) : Promise.resolve([])
        ]);
        setTools(Array.isArray(toolsData) ? toolsData : []);
        setDepartments(Array.isArray(departmentsData) ? departmentsData : []);
      } catch (error) {
        console.error('Failed to load data:', error);
        setTools([]);
        setDepartments([]);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [token, user.role]);

  const handleAddTool = async (e) => {
    e.preventDefault();
    try {
      // If user is supervisor, automatically use their department_id
      const toolData = {
        ...newTool,
        department_id: user.role === 'supervisor' ? user.department_id : newTool.department_id
      };
      
      const result = await api.createTool(token, toolData);
      if (result && result.error) {
        alert(result.error);
      } else if (result) {
        setTools([result, ...tools]);
        setNewTool({
          name: '',
          type: '',
          description: '',
          serial_number: '',
          purchase_date: '',
          department_id: ''
        });
        setShowAddForm(false);
      }
    } catch (error) {
      alert('Failed to add tool');
    }
  };

  const getStatusBadge = (status) => {
    const colors = {
      available: 'bg-green-100 text-green-800',
      assigned: 'bg-yellow-100 text-yellow-800',
      maintenance: 'bg-red-100 text-red-800'
    };
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[status] || 'bg-gray-100 text-gray-800'}`}>
        {status?.charAt(0).toUpperCase() + status?.slice(1) || 'Unknown'}
      </span>
    );
  };

  if (loading) {
    return <div className="p-6">Loading tools...</div>;
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Tool Management</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Add Tool</span>
        </button>
      </div>

      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New Tool</h2>
            <form onSubmit={handleAddTool} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  value={newTool.name}
                  onChange={(e) => setNewTool({...newTool, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <input
                  type="text"
                  value={newTool.type}
                  onChange={(e) => setNewTool({...newTool, type: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={newTool.description}
                  onChange={(e) => setNewTool({...newTool, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  rows="3"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Serial Number</label>
                <input
                  type="text"
                  value={newTool.serial_number}
                  onChange={(e) => setNewTool({...newTool, serial_number: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Purchase Date</label>
                <input
                  type="date"
                  value={newTool.purchase_date}
                  onChange={(e) => setNewTool({...newTool, purchase_date: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              {/* Only show department selection for farm owners */}
              {user.role === 'farm_owner' && departments.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <select
                    value={newTool.department_id}
                    onChange={(e) => setNewTool({...newTool, department_id: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select Department</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                </div>
              )}
              
              {/* Show current department for supervisors */}
              {user.role === 'supervisor' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <div className="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-gray-700">
                    {user.department_name || 'Your Department'}
                  </div>
                </div>
              )}
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700"
                >
                  Add Tool
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool) => (
          <div key={tool.id} className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Wrench className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{tool.name}</h3>
                  <p className="text-sm text-gray-600">{tool.type}</p>
                </div>
              </div>
              {getStatusBadge(tool.status)}
            </div>
            
            {tool.description && (
              <p className="text-gray-600 text-sm mb-3">{tool.description}</p>
            )}
            
            <div className="space-y-2 text-sm">
              {tool.serial_number && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Serial:</span>
                  <span className="text-gray-900">{tool.serial_number}</span>
                </div>
              )}
              {tool.purchase_date && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Purchased:</span>
                  <span className="text-gray-900">
                    {new Date(tool.purchase_date).toLocaleDateString()}
                  </span>
                </div>
              )}
              {tool.department_name && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Department:</span>
                  <span className="text-gray-900">{tool.department_name}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Enhanced Task Management Component with completion functionality


const TaskManagement = ({ token, user }) => {
  const [tasks, setTasks] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showAssignForm, setShowAssignForm] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [loading, setLoading] = useState(true);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    priority: 'medium',
    due_date: '',
    department_id: ''
  });
  const [taskAssignment, setTaskAssignment] = useState({
    employee_id: '',
    notes: ''
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        const [tasksData, employeesData, departmentsData] = await Promise.all([
          api.getTasks(token),
          api.getEmployees(token),
          user.role === 'farm_owner' ? api.getDepartments(token) : Promise.resolve([])
        ]);
        setTasks(Array.isArray(tasksData) ? tasksData : []);
        setEmployees(Array.isArray(employeesData) ? employeesData : []);
        setDepartments(Array.isArray(departmentsData) ? departmentsData : []);
      } catch (error) {
        console.error('Failed to load data:', error);
        setTasks([]);
        setEmployees([]);
        setDepartments([]);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [token, user.role]);

  const handleAddTask = async (e) => {
    e.preventDefault();
    try {
      const taskData = {
        ...newTask,
        department_id: user.role === 'supervisor' ? user.department_id : newTask.department_id
      };
      
      const result = await api.createTask(token, taskData);
      if (result && result.error) {
        alert(result.error);
      } else if (result) {
        setTasks([result, ...tasks]);
        setNewTask({
          title: '',
          description: '',
          priority: 'medium',
          due_date: '',
          department_id: ''
        });
        setShowAddForm(false);
      }
    } catch (error) {
      alert('Failed to add task');
    }
  };

const handleUpdateTaskStatus = async (taskId, newStatus) => {
  console.log('Updating task', taskId, 'to status', newStatus);
  
  try {
    const response = await fetch(`${API_BASE_URL}/api/tasks/${taskId}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ 
        status: newStatus,
        notes: newStatus === 'completed' ? 'Marked as completed via dashboard' : undefined
      })
    });

    console.log('Response status:', response.status);
    console.log('Response ok:', response.ok);

    // Check if response is actually JSON
    const contentType = response.headers.get('content-type');
    console.log('Content type:', contentType);
    
    let result;
    if (contentType && contentType.includes('application/json')) {
      result = await response.json();
    } else {
      // If not JSON, get the text to see what the server returned
      const text = await response.text();
      console.error('Server returned non-JSON response:', text);
      throw new Error(`Server returned non-JSON response. Status: ${response.status}`);
    }

    console.log('Result:', result);
    
    if (response.ok && result.success) {
      // Update the task in state
      setTasks(tasks.map(task => 
        task.id === taskId 
          ? { ...task, status: newStatus, updated_at: new Date().toISOString() }
          : task
      ));
      
      // Show success message
      const action = newStatus === 'completed' ? 'completed' : 
                     newStatus === 'in_progress' ? 'started' : 'updated';
      alert(`Task ${action} successfully! ✅`);
      
      console.log('Task updated successfully in UI');
    } else {
      console.error('API error:', result);
      alert(result.error || result.message || 'Failed to update task status');
    }
  } catch (error) {
    console.error('Error updating task status:', error);
    
    // More specific error messages
    if (error.message.includes('Failed to fetch')) {
      alert('Cannot connect to server. Is your backend running?');
    } else if (error.message.includes('non-JSON response')) {
      alert('Server error: Got HTML instead of JSON. Check server console for errors.');
    } else {
      alert(`Failed to update task status: ${error.message}`);
    }
  }
};

  const handleAssignTask = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`${API_BASE_URL}/api/tasks/assign`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          task_id: selectedTask.id,
          employee_id: taskAssignment.employee_id,
          notes: taskAssignment.notes
        })
      });

      const result = await response.json();
      
      if (response.ok) {
        // Update task status to in_progress
        setTasks(tasks.map(task => 
          task.id === selectedTask.id 
            ? { ...task, status: 'in_progress', updated_at: new Date().toISOString() }
            : task
        ));
        
        alert('Task assigned successfully!');
        setShowAssignForm(false);
        setSelectedTask(null);
        setTaskAssignment({ employee_id: '', notes: '' });
      } else {
        alert(result.error || 'Failed to assign task');
      }
    } catch (error) {
      console.error('Error assigning task:', error);
      alert('Failed to assign task');
    }
  };

  const getPriorityBadge = (priority) => {
    const colors = {
      high: 'bg-red-100 text-red-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-green-100 text-green-800'
    };
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[priority] || 'bg-gray-100 text-gray-800'}`}>
        {priority?.charAt(0).toUpperCase() + priority?.slice(1) || 'Unknown'}
      </span>
    );
  };

  const getStatusBadge = (status) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      in_progress: 'bg-blue-100 text-blue-800',
      completed: 'bg-green-100 text-green-800'
    };
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[status] || 'bg-gray-100 text-gray-800'}`}>
        {status?.replace('_', ' ').charAt(0).toUpperCase() + status?.replace('_', ' ').slice(1) || 'Unknown'}
      </span>
    );
  };

  if (loading) {
    return <div className="p-6">Loading tasks...</div>;
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Task Management</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Add Task</span>
        </button>
      </div>

      {/* Add Task Form */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New Task</h2>
            <form onSubmit={handleAddTask} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  value={newTask.title}
                  onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={newTask.description}
                  onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  rows="3"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                <select
                  value={newTask.priority}
                  onChange={(e) => setNewTask({...newTask, priority: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                <input
                  type="date"
                  value={newTask.due_date}
                  onChange={(e) => setNewTask({...newTask, due_date: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              {user.role === 'farm_owner' && departments.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <select
                    value={newTask.department_id}
                    onChange={(e) => setNewTask({...newTask, department_id: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select Department</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                </div>
              )}
              {user.role === 'supervisor' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <div className="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-gray-700">
                    {user.department_name || 'Your Department'}
                  </div>
                </div>
              )}
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700"
                >
                  Add Task
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Assign Task Form */}
      {showAssignForm && selectedTask && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Assign Task: {selectedTask.title}</h2>
            <form onSubmit={handleAssignTask} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Assign to Employee</label>
                <select
                  value={taskAssignment.employee_id}
                  onChange={(e) => setTaskAssignment({...taskAssignment, employee_id: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  required
                >
                  <option value="">Select Employee</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.first_name} {emp.last_name} - {emp.position}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Assignment Notes</label>
                <textarea
                  value={taskAssignment.notes}
                  onChange={(e) => setTaskAssignment({...taskAssignment, notes: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  rows="3"
                  placeholder="Special instructions or notes..."
                />
              </div>
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
                >
                  Assign Task
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAssignForm(false);
                    setSelectedTask(null);
                    setTaskAssignment({ employee_id: '', notes: '' });
                  }}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Task List */}
      <div className="space-y-4">
        {tasks.map((task) => (
          <div key={task.id} className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-gray-900">{task.title}</h3>
                  {getPriorityBadge(task.priority)}
                  {getStatusBadge(task.status)}
                </div>
                {task.description && (
                  <p className="text-gray-600 mb-3">{task.description}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center ml-4">
                <CheckSquare className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            
            <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
              <div className="flex items-center space-x-4">
                {task.due_date && (
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>Due: {new Date(task.due_date).toLocaleDateString()}</span>
                  </div>
                )}
                {task.department_name && (
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>{task.department_name}</span>
                  </div>
                )}
              </div>
              <div className="text-xs">
                Created: {new Date(task.created_at).toLocaleDateString()}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-3">
              {task.status === 'pending' && (
                <>
                  <button
                    onClick={() => handleUpdateTaskStatus(task.id, 'in_progress')}
                    className="bg-blue-600 text-white px-3 py-1 rounded-lg text-sm hover:bg-blue-700 flex items-center space-x-1"
                  >
                    <Clock className="w-4 h-4" />
                    <span>Start Task</span>
                  </button>
                  <button
                    onClick={() => {
                      setSelectedTask(task);
                      setShowAssignForm(true);
                    }}
                    className="bg-purple-600 text-white px-3 py-1 rounded-lg text-sm hover:bg-purple-700 flex items-center space-x-1"
                  >
                    <Users className="w-4 h-4" />
                    <span>Assign</span>
                  </button>
                </>
              )}
              {task.status === 'in_progress' && (
                <button
                  onClick={() => handleUpdateTaskStatus(task.id, 'completed')}
                  className="bg-green-600 text-white px-3 py-1 rounded-lg text-sm hover:bg-green-700 flex items-center space-x-1"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Mark Complete</span>
                </button>
              )}
              {task.status === 'completed' && (
                <div className="flex items-center space-x-2 text-green-600">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">Task Completed</span>
                </div>
              )}
              {task.status !== 'completed' && (
                <button
                  onClick={() => handleUpdateTaskStatus(task.id, 'completed')}
                  className="bg-green-600 text-white px-3 py-1 rounded-lg text-sm hover:bg-green-700 flex items-center space-x-1"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Complete</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Profile Component
const Profile = ({ user }) => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Profile</h1>
      
      <div className="bg-white p-8 rounded-xl shadow-md max-w-2xl">
        <div className="flex items-center space-x-6 mb-8">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
            <User className="w-10 h-10 text-green-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{user.username}</h2>
            <p className="text-gray-600 capitalize">{user.role?.replace('_', ' ')}</p>
            {user.department_name && (
              <p className="text-sm text-gray-500">Department: {user.department_name}</p>
            )}
          </div>
        </div>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
            <div className="p-3 bg-gray-50 rounded-lg text-gray-900">{user.username}</div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <div className="p-3 bg-gray-50 rounded-lg text-gray-900 flex items-center space-x-2">
              <Mail className="w-4 h-4 text-gray-500" />
              <span>{user.email}</span>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
            <div className="p-3 bg-gray-50 rounded-lg text-gray-900 capitalize">
              {user.role?.replace('_', ' ')}
            </div>
          </div>
          
          {user.department_name && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
              <div className="p-3 bg-gray-50 rounded-lg text-gray-900">
                {user.department_name}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Main App Component
const FarmManagementApp = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [token, setToken] = useState('');
  const [activeTab, setActiveTab] = useState('dashboard');

  // Check for existing authentication on component mount
  useEffect(() => {
    const savedToken = localStorage.getItem('farm_token');
    const savedUser = localStorage.getItem('farm_user');
    
    if (savedToken && savedUser) {
      try {
        setToken(savedToken);
        setUser(JSON.parse(savedUser));
        setIsAuthenticated(true);
      } catch (error) {
        // Clear invalid data
        localStorage.removeItem('farm_token');
        localStorage.removeItem('farm_user');
      }
    }
  }, []);

  const handleLogin = (newToken, newUser) => {
    setToken(newToken);
    setUser(newUser);
    setIsAuthenticated(true);
    
    // Save to localStorage for persistence
    localStorage.setItem('farm_token', newToken);
    localStorage.setItem('farm_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setToken('');
    setUser(null);
    setIsAuthenticated(false);
    setActiveTab('dashboard');
    
    // Clear from localStorage
    localStorage.removeItem('farm_token');
    localStorage.removeItem('farm_user');
  };

  // Listen for custom events from the dashboard quick actions
  useEffect(() => {
    const handleSetActiveTab = (event) => {
      setActiveTab(event.detail);
    };

    window.addEventListener('setActiveTab', handleSetActiveTab);
    return () => window.removeEventListener('setActiveTab', handleSetActiveTab);
  }, []);

  // Render login screen if not authenticated
  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  // Render main dashboard
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        user={user}
        onLogout={handleLogout}
      />
      
      <div className="flex-1 overflow-y-auto">
        {activeTab === 'dashboard' && <Dashboard token={token} user={user} />}
        {activeTab === 'reports' && <Reports token={token} user={user} />}
        {activeTab === 'activity' && <ActivityPage user={user} />}
        {activeTab === 'employees' && <EmployeeManagement token={token} user={user} />}
        {activeTab === 'tools' && <ToolManagement token={token} user={user} />}
        {activeTab === 'tasks' && <TaskManagement token={token} user={user} />}
        {activeTab === 'profile' && <Profile user={user} />}
      </div>
    </div>
  );
};

export default FarmManagementApp;