//this is the main entry point of our code
const express = require('express');
const cors = require('cors');
require('dotenv').config();

// Import routes
const authRoutes = require('./src/routes/auth');
const employeeRoutes = require('./src/routes/employees');
const toolRoutes = require('./src/routes/tools');
const taskRoutes = require('./src/routes/tasks');
const assignmentRoutes = require('./src/routes/assignments');
const dashboardRoutes = require('./src/routes/dashboard');
const userRoutes = require('./src/routes/users');

// Import middleware
const { globalErrorHandler } = require('./src/middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/tools', toolRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/assignments', assignmentRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/users', userRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Root endpoint for basic info
app.get('/', (req, res) => {
  res.json({ 
    message: 'Farm Management System API',
    version: '1.0.0',
    endpoints: {
      health: '/api/health',
      auth: '/api/auth',
      employees: '/api/employees (requires auth)',
      tools: '/api/tools (requires auth)',
      tasks: '/api/tasks (requires auth)',
      assignments: '/api/assignments (requires auth)',
      dashboard: '/api/dashboard (requires auth)',
      users: '/api/users (requires auth)'
    }
  });
});

// Test route
app.get('/api/test/db', require('./src/controllers/authController').testDatabase);

// 404 handler for unmatched routes
app.use('*', (req, res) => {
  res.status(404).json({ 
    error: 'Route not found',
    path: req.originalUrl,
    method: req.method
  });
});

// Global error handler - MUST be last middleware
app.use(globalErrorHandler);

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log('Farm Management System with Authentication');
  console.log('API Base URL: http://localhost:' + PORT);
  console.log('Default login credentials:');
  console.log('Farm Owner: username=farmowner, password=password123');
  console.log('Plantation Supervisor: username=plantation_supervisor, password=password123');
  console.log('Livestock Supervisor: username=livestock_supervisor, password=password123');
  console.log('Poultry Supervisor: username=poultry_supervisor, password=password123');
  console.log('Fishery Supervisor: username=fishery_supervisor, password=password123');
});

module.exports = app;