import React, { useState, useEffect } from 'react';
import { User, Users, Wrench, CheckSquare, BarChart3, LogOut, Plus, Edit, Trash2, Calendar, MapPin, Phone, Mail, AlertCircle, CheckCircle, Clock, Settings, Home, TrendingUp, Activity } from 'lucide-react';

// API Configuration
const API_BASE_URL = 'http://localhost:5000'; // Adjust this to your backend URL

// API Helper Functions
const api = {
  // Auth endpoints
  login: async (credentials) => {
    const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(credentials)
    });
    return response.json();
  },
  
  // Dashboard endpoints
  getDashboard: async (token) => {
    const response = await fetch(`${API_BASE_URL}/api/dashboard`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },
  
  // Employee endpoints
  getEmployees: async (token) => {
    const response = await fetch(`${API_BASE_URL}/api/employees`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },
  
  createEmployee: async (token, employeeData) => {
    const response = await fetch(`${API_BASE_URL}/api/employees`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      },
      body: JSON.stringify(employeeData)
    });
    return response.json();
  },
  
  deleteEmployee: async (token, id) => {
    const response = await fetch(`${API_BASE_URL}/api/employees/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },
  
  // Tool endpoints
  getTools: async (token) => {
    const response = await fetch(`${API_BASE_URL}/api/tools`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },
  
  createTool: async (token, toolData) => {
    const response = await fetch(`${API_BASE_URL}/api/tools`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      },
      body: JSON.stringify(toolData)
    });
    return response.json();
  },
  
  // Task endpoints
  getTasks: async (token) => {
    const response = await fetch(`${API_BASE_URL}/api/tasks`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },
  
  createTask: async (token, taskData) => {
    const response = await fetch(`${API_BASE_URL}/api/tasks`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      },
      body: JSON.stringify(taskData)
    });
    return response.json();
  },
  
  // Assignment endpoints
  assignTool: async (token, assignmentData) => {
    const response = await fetch(`${API_BASE_URL}/api/assignments/tools`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      },
      body: JSON.stringify(assignmentData)
    });
    return response.json();
  },
  
  assignTask: async (token, assignmentData) => {
    const response = await fetch(`${API_BASE_URL}/api/assignments/tasks`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      },
      body: JSON.stringify(assignmentData)
    });
    return response.json();
  },
  
  getEmployeeTools: async (token, employeeId) => {
    const response = await fetch(`${API_BASE_URL}/api/assignments/employee/${employeeId}/tools`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  },
  
  returnTool: async (token, assignmentId, notes) => {
    const response = await fetch(`${API_BASE_URL}/api/assignments/tools/${assignmentId}/return`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      },
      body: JSON.stringify({ notes })
    });
    return response.json();
  },
  
  getDepartments: async (token) => {
    const response = await fetch(`${API_BASE_URL}/api/dashboard/departments`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    return response.json();
  }
};

// Login Component
const Login = ({ onLogin }) => {
  const [credentials, setCredentials] = useState({ username: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const result = await api.login(credentials);
      if (result.error) {
        setError(result.error);
      } else {
        onLogin(result.token, result.user);
      }
    } catch (error) {
      setError('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-400 to-blue-600 flex items-center justify-center">
      <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-md">
        <div className="text-center mb-8">
          <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <Home className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Farm Management</h1>
          <p className="text-gray-600">Sign in to your account</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">
              {error}
            </div>
          )}
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
            <input
              type="text"
              value={credentials.username}
              onChange={(e) => setCredentials({...credentials, username: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
            <input
              type="password"
              value={credentials.password}
              onChange={(e) => setCredentials({...credentials, password: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              required
            />
          </div>
          
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 focus:ring-4 focus:ring-green-200 transition-colors disabled:opacity-50"
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
};

// Weather Widget Component
const WeatherWidget = () => {
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    // Demo weather data - replace with real API later
    setTimeout(() => {
      setWeather({
        location: 'Kitwe, ZM',
        temp: 24,
        condition: 'Partly Cloudy',
        humidity: 65,
        wind: 3.2,
        advice: 'Good weather for field work'
      });
    }, 1000);
  }, []);

  if (!weather) {
    return (
      <div className="bg-blue-600 p-4 rounded-lg text-white animate-pulse">
        <div className="h-4 bg-blue-500 rounded mb-2"></div>
        <div className="h-6 bg-blue-500 rounded"></div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-4 rounded-lg">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h4 className="font-medium text-sm">{weather.location}</h4>
          <p className="text-2xl font-bold">{weather.temp}°C</p>
          <p className="text-xs text-blue-100">{weather.condition}</p>
        </div>
        <div className="text-2xl">⛅</div>
      </div>
      <div className="text-xs space-y-1">
        <div className="flex justify-between">
          <span>Humidity:</span>
          <span>{weather.humidity}%</span>
        </div>
        <div className="flex justify-between">
          <span>Wind:</span>
          <span>{weather.wind} m/s</span>
        </div>
        <div className="pt-2 border-t border-blue-400">
          <p className="text-blue-100">{weather.advice}</p>
        </div>
      </div>
    </div>
  );
};

// Activity Feed Component
const ActivityFeed = ({ user }) => {
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    // Generate demo activities
    const demoActivities = [
      {
        id: 1,
        icon: '🔐',
        description: `${user.username} logged into the system`,
        time: 'Just now',
        type: 'login'
      },
      {
        id: 2,
        icon: '📋',
        description: 'New task created: Feed Livestock',
        time: '5m ago',
        type: 'task'
      },
      {
        id: 3,
        icon: '🌤️',
        description: 'Weather updated: Good conditions',
        time: '30m ago',
        type: 'weather'
      },
      {
        id: 4,
        icon: '👤',
        description: 'Employee Lisa Davis added',
        time: '1h ago',
        type: 'employee'
      }
    ];
    
    setActivities(demoActivities);
    
    // Simulate real-time updates
    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        const newActivity = {
          id: Date.now(),
          icon: '⚙️',
          description: 'System maintenance completed',
          time: 'Just now',
          type: 'system'
        };
        setActivities(prev => [newActivity, ...prev.slice(0, 4)]);
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [user.username]);

  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-medium text-gray-700 text-sm">Recent Activity</h3>
        <div className="flex items-center space-x-1">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-xs text-green-600">Live</span>
        </div>
      </div>
      <div className="space-y-2">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start space-x-2 p-2 hover:bg-gray-50 rounded text-xs">
            <span className="text-sm">{activity.icon}</span>
            <div className="flex-1 min-w-0">
              <p className="text-gray-800 text-xs">{activity.description}</p>
              <p className="text-gray-500 text-xs">{activity.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Updated Sidebar Navigation
const Sidebar = ({ activeTab, setActiveTab, user, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'reports', label: 'Reports', icon: TrendingUp },
    { id: 'activity', label: 'Activity', icon: Activity },
    { id: 'employees', label: 'Employees', icon: Users },
    { id: 'tools', label: 'Tools', icon: Wrench },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    { id: 'profile', label: 'Profile', icon: User }
  ];

  return (
    <div className="bg-gray-900 text-white w-64 min-h-screen flex flex-col">
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <Home className="w-8 h-8 text-green-400" />
          <h1 className="text-xl font-bold">Farm Manager</h1>
        </div>
      </div>
      
      {/* Weather Widget */}
      <div className="px-4 mb-4">
        <WeatherWidget />
      </div>
      
      <nav className="flex-1 px-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                activeTab === item.id 
                  ? 'bg-green-600 text-white' 
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
            <User className="w-6 h-6" />
          </div>
          <div>
            <p className="font-medium">{user.username}</p>
            <p className="text-sm text-gray-400 capitalize">{user.role.replace('_', ' ')}</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center space-x-3 px-4 py-2 text-red-400 hover:bg-gray-800 rounded-lg transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </div>
  );
};

// Dashboard Component
const Dashboard = ({ token, user }) => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const loadDashboard = async () => {
    try {
      const data = await api.getDashboard(token);
      setDashboardData(data);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Failed to load dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboard();
    
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadDashboard, 30000);
    
    // Cleanup interval on component unmount
    return () => clearInterval(interval);
  }, [token]);

  // Manual refresh function
  const handleRefresh = () => {
    setLoading(true);
    loadDashboard();
  };

  if (loading && !dashboardData) {
    return <div className="p-6">Loading dashboard...</div>;
  }

  const stats = [
    {
      label: 'Total Employees',
      value: dashboardData?.total_employees || 0,
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      label: 'Total Tools',
      value: dashboardData?.total_tools || 0,
      icon: Wrench,
      color: 'bg-green-500'
    },
    {
      label: 'Pending Tasks',
      value: dashboardData?.pending_tasks || 0,
      icon: CheckSquare,
      color: 'bg-yellow-500'
    },
    {
      label: 'Active Assignments',
      value: dashboardData?.active_tool_assignments || 0,
      icon: Clock,
      color: 'bg-purple-500'
    }
  ];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-500">
            Last updated: {lastUpdated.toLocaleTimeString()}
          </span>
          <button
            onClick={handleRefresh}
            disabled={loading}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
          >
            <svg className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            <span>{loading ? 'Refreshing...' : 'Refresh'}</span>
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions and Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button 
              onClick={() => window.dispatchEvent(new CustomEvent('setActiveTab', { detail: 'employees' }))}
              className="w-full text-left px-4 py-2 bg-green-50 hover:bg-green-100 rounded-lg text-green-700 transition-colors"
            >
              ➕ Add New Employee
            </button>
            <button 
              onClick={() => window.dispatchEvent(new CustomEvent('setActiveTab', { detail: 'tools' }))}
              className="w-full text-left px-4 py-2 bg-blue-50 hover:bg-blue-100 rounded-lg text-blue-700 transition-colors"
            >
              🔧 Register New Tool
            </button>
            <button 
              onClick={() => window.dispatchEvent(new CustomEvent('setActiveTab', { detail: 'tasks' }))}
              className="w-full text-left px-4 py-2 bg-purple-50 hover:bg-purple-100 rounded-lg text-purple-700 transition-colors"
            >
              📋 Create New Task
            </button>
          </div>
        </div>

        <div className="lg:col-span-2">
          <ActivityFeed user={user} />
        </div>
      </div>

      {user.role === 'farm_owner' && dashboardData?.department_breakdown && (
        <div className="bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Department Overview</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Department</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Employees</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Tools</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Tasks</th>
                </tr>
              </thead>
              <tbody>
                {dashboardData.department_breakdown.map((dept, index) => (
                  <tr key={index} className="border-b border-gray-100">
                    <td className="py-3 px-4">{dept.department_name}</td>
                    <td className="py-3 px-4">{dept.employee_count}</td>
                    <td className="py-3 px-4">{dept.tool_count}</td>
                    <td className="py-3 px-4">{dept.task_count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

// Simple Reports Component
const Reports = ({ token, user }) => {
  const [loading, setLoading] = useState(true);
  const [reportData, setReportData] = useState(null);

  useEffect(() => {
    // Simulate loading reports
    setTimeout(() => {
      setReportData({
        efficiency: 85,
        taskCompletion: 92,
        toolUsage: 78,
        productivity: 88
      });
      setLoading(false);
    }, 1500);
  }, []);

  if (loading) {
    return <div className="p-6">Loading reports...</div>;
  }

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Reports & Analytics</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[
          { label: 'Farm Efficiency', value: `${reportData.efficiency}%`, color: 'bg-blue-500' },
          { label: 'Task Completion', value: `${reportData.taskCompletion}%`, color: 'bg-green-500' },
          { label: 'Tool Usage', value: `${reportData.toolUsage}%`, color: 'bg-yellow-500' },
          { label: 'Productivity', value: `${reportData.productivity}%`, color: 'bg-purple-500' }
        ].map((metric, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{metric.label}</p>
                <p className="text-3xl font-bold text-gray-900">{metric.value}</p>
              </div>
              <div className={`${metric.color} p-3 rounded-lg`}>
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white p-6 rounded-xl shadow-md text-center">
        <TrendingUp className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-700 mb-2">Advanced Analytics</h3>
        <p className="text-gray-600">Detailed charts and insights coming soon!</p>
      </div>
    </div>
  );
};

// Activity Page Component
const ActivityPage = ({ user }) => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Activity Feed</h1>
      <div className="max-w-2xl">
        <ActivityFeed user={user} />
      </div>
    </div>
  );
};

// Employee Management Component - Fixed Version
const EmployeeManagement = ({ token, user }) => {
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [newEmployee, setNewEmployee] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    position: '',
    department_id: ''
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        setError('');
        
        console.log('Loading employees data...');
        
        const [employeesResponse, departmentsResponse] = await Promise.allSettled([
          api.getEmployees(token),
          user.role === 'farm_owner' ? api.getDepartments(token) : Promise.resolve([])
        ]);

        console.log('Employees response:', employeesResponse);
        console.log('Departments response:', departmentsResponse);

        // Handle employees data
        if (employeesResponse.status === 'fulfilled') {
          const employeesData = employeesResponse.value;
          if (Array.isArray(employeesData)) {
            setEmployees(employeesData);
          } else if (employeesData && employeesData.error) {
            setError(`Failed to load employees: ${employeesData.error}`);
            setEmployees([]);
          } else {
            console.warn('Unexpected employees data format:', employeesData);
            setEmployees([]);
          }
        } else {
          console.error('Failed to fetch employees:', employeesResponse.reason);
          setError('Failed to load employees');
          setEmployees([]);
        }

        // Handle departments data
        if (departmentsResponse.status === 'fulfilled') {
          const departmentsData = departmentsResponse.value;
          if (Array.isArray(departmentsData)) {
            setDepartments(departmentsData);
          } else {
            setDepartments([]);
          }
        } else {
          console.error('Failed to fetch departments:', departmentsResponse.reason);
          setDepartments([]);
        }

      } catch (error) {
        console.error('Failed to load data:', error);
        setError('Failed to load data');
        setEmployees([]);
        setDepartments([]);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [token, user.role]);

  const handleAddEmployee = async (e) => {
    e.preventDefault();
    try {
      // If user is supervisor, automatically use their department_id
      const employeeData = {
        ...newEmployee,
        department_id: user.role === 'supervisor' ? user.department_id : newEmployee.department_id
      };
      
      const result = await api.createEmployee(token, employeeData);
      if (result && result.error) {
        alert(result.error);
      } else if (result) {
        setEmployees([result, ...employees]);
        setNewEmployee({
          first_name: '',
          last_name: '',
          email: '',
          phone: '',
          position: '',
          department_id: ''
        });
        setShowAddForm(false);
      } else {
        alert('Failed to add employee - no response');
      }
    } catch (error) {
      console.error('Error adding employee:', error);
      alert('Failed to add employee');
    }
  };

  const handleDeleteEmployee = async (id) => {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      try {
        await api.deleteEmployee(token, id);
        setEmployees(employees.filter(emp => emp.id !== id));
      } catch (error) {
        console.error('Error deleting employee:', error);
        alert('Failed to delete employee');
      }
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-green-500"></div>
        </div>
        <p className="text-center mt-4">Loading employees...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error Loading Employees</h3>
              <div className="mt-2 text-sm text-red-700">
                <p>{error}</p>
              </div>
              <div className="mt-4">
                <button
                  onClick={() => window.location.reload()}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
                >
                  Retry
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Employee Management</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Add Employee</span>
        </button>
      </div>

      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New Employee</h2>
            <form onSubmit={handleAddEmployee} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                  <input
                    type="text"
                    value={newEmployee.first_name}
                    onChange={(e) => setNewEmployee({...newEmployee, first_name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                  <input
                    type="text"
                    value={newEmployee.last_name}
                    onChange={(e) => setNewEmployee({...newEmployee, last_name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  value={newEmployee.email}
                  onChange={(e) => setNewEmployee({...newEmployee, email: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="tel"
                  value={newEmployee.phone}
                  onChange={(e) => setNewEmployee({...newEmployee, phone: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Position</label>
                <input
                  type="text"
                  value={newEmployee.position}
                  onChange={(e) => setNewEmployee({...newEmployee, position: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              {/* Only show department selection for farm owners */}
              {user.role === 'farm_owner' && departments.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <select
                    value={newEmployee.department_id}
                    onChange={(e) => setNewEmployee({...newEmployee, department_id: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select Department</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                </div>
              )}
              
              {/* Show current department for supervisors */}
              {user.role === 'supervisor' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <div className="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-gray-700">
                    {user.department_name || 'Your Department'}
                  </div>
                </div>
              )}
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700"
                >
                  Add Employee
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {employees.length === 0 ? (
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-700 mb-2">No Employees Found</h3>
          <p className="text-gray-600">Get started by adding your first employee.</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Name</th>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Email</th>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Position</th>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Department</th>
                <th className="text-left py-3 px-6 font-semibold text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((employee, index) => (
                <tr key={employee.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                  <td className="py-4 px-6">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <User className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">
                          {employee.first_name} {employee.last_name}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-gray-600">{employee.email}</td>
                  <td className="py-4 px-6 text-gray-600">{employee.position || '-'}</td>
                  <td className="py-4 px-6 text-gray-600">{employee.department_name || '-'}</td>
                  <td className="py-4 px-6">
                    <button
                      onClick={() => handleDeleteEmployee(employee.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// Tool Management Component
const ToolManagement = ({ token, user }) => {
  const [tools, setTools] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newTool, setNewTool] = useState({
    name: '',
    type: '',
    description: '',
    serial_number: '',
    purchase_date: '',
    department_id: ''
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        const [toolsData, departmentsData] = await Promise.all([
          api.getTools(token),
          user.role === 'farm_owner' ? api.getDepartments(token) : Promise.resolve([])
        ]);
        setTools(toolsData);
        setDepartments(departmentsData);
      } catch (error) {
        console.error('Failed to load data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [token, user.role]);

  const handleAddTool = async (e) => {
    e.preventDefault();
    try {
      // If user is supervisor, automatically use their department_id
      const toolData = {
        ...newTool,
        department_id: user.role === 'supervisor' ? user.department_id : newTool.department_id
      };
      
      const result = await api.createTool(token, toolData);
      if (result.error) {
        alert(result.error);
      } else {
        setTools([result, ...tools]);
        setNewTool({
          name: '',
          type: '',
          description: '',
          serial_number: '',
          purchase_date: '',
          department_id: ''
        });
        setShowAddForm(false);
      }
    } catch (error) {
      alert('Failed to add tool');
    }
  };

  const getStatusBadge = (status) => {
    const colors = {
      available: 'bg-green-100 text-green-800',
      assigned: 'bg-yellow-100 text-yellow-800',
      maintenance: 'bg-red-100 text-red-800'
    };
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[status] || 'bg-gray-100 text-gray-800'}`}>
        {status?.charAt(0).toUpperCase() + status?.slice(1) || 'Unknown'}
      </span>
    );
  };

  if (loading) {
    return <div className="p-6">Loading tools...</div>;
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Tool Management</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Add Tool</span>
        </button>
      </div>

      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New Tool</h2>
            <form onSubmit={handleAddTool} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  value={newTool.name}
                  onChange={(e) => setNewTool({...newTool, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <input
                  type="text"
                  value={newTool.type}
                  onChange={(e) => setNewTool({...newTool, type: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={newTool.description}
                  onChange={(e) => setNewTool({...newTool, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  rows="3"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Serial Number</label>
                <input
                  type="text"
                  value={newTool.serial_number}
                  onChange={(e) => setNewTool({...newTool, serial_number: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Purchase Date</label>
                <input
                  type="date"
                  value={newTool.purchase_date}
                  onChange={(e) => setNewTool({...newTool, purchase_date: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              {/* Only show department selection for farm owners */}
              {user.role === 'farm_owner' && departments.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <select
                    value={newTool.department_id}
                    onChange={(e) => setNewTool({...newTool, department_id: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select Department</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                </div>
              )}
              
              {/* Show current department for supervisors */}
              {user.role === 'supervisor' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <div className="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-gray-700">
                    {user.department_name || 'Your Department'}
                  </div>
                </div>
              )}
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700"
                >
                  Add Tool
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool) => (
          <div key={tool.id} className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Wrench className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{tool.name}</h3>
                  <p className="text-sm text-gray-600">{tool.type}</p>
                </div>
              </div>
              {getStatusBadge(tool.status)}
            </div>
            
            {tool.description && (
              <p className="text-gray-600 text-sm mb-3">{tool.description}</p>
            )}
            
            <div className="space-y-2 text-sm">
              {tool.serial_number && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Serial:</span>
                  <span className="text-gray-900">{tool.serial_number}</span>
                </div>
              )}
              {tool.purchase_date && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Purchased:</span>
                  <span className="text-gray-900">
                    {new Date(tool.purchase_date).toLocaleDateString()}
                  </span>
                </div>
              )}
              {tool.department_name && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Department:</span>
                  <span className="text-gray-900">{tool.department_name}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Task Management Component
const TaskManagement = ({ token, user }) => {
  const [tasks, setTasks] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    priority: 'medium',
    due_date: '',
    department_id: ''
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        const [tasksData, departmentsData] = await Promise.all([
          api.getTasks(token),
          user.role === 'farm_owner' ? api.getDepartments(token) : Promise.resolve([])
        ]);
        setTasks(tasksData);
        setDepartments(departmentsData);
      } catch (error) {
        console.error('Failed to load data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [token, user.role]);

  const handleAddTask = async (e) => {
    e.preventDefault();
    try {
      // If user is supervisor, automatically use their department_id
      const taskData = {
        ...newTask,
        department_id: user.role === 'supervisor' ? user.department_id : newTask.department_id
      };
      
      const result = await api.createTask(token, taskData);
      if (result.error) {
        alert(result.error);
      } else {
        setTasks([result, ...tasks]);
        setNewTask({
          title: '',
          description: '',
          priority: 'medium',
          due_date: '',
          department_id: ''
        });
        setShowAddForm(false);
      }
    } catch (error) {
      alert('Failed to add task');
    }
  };

  const getPriorityBadge = (priority) => {
    const colors = {
      high: 'bg-red-100 text-red-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-green-100 text-green-800'
    };
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[priority] || 'bg-gray-100 text-gray-800'}`}>
        {priority?.charAt(0).toUpperCase() + priority?.slice(1) || 'Unknown'}
      </span>
    );
  };

  const getStatusBadge = (status) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      in_progress: 'bg-blue-100 text-blue-800',
      completed: 'bg-green-100 text-green-800'
    };
    
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[status] || 'bg-gray-100 text-gray-800'}`}>
        {status?.replace('_', ' ').charAt(0).toUpperCase() + status?.replace('_', ' ').slice(1) || 'Unknown'}
      </span>
    );
  };

  if (loading) {
    return <div className="p-6">Loading tasks...</div>;
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Task Management</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center space-x-2"
        >
          <Plus className="w-5 h-5" />
          <span>Add Task</span>
        </button>
      </div>

      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">Add New Task</h2>
            <form onSubmit={handleAddTask} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  value={newTask.title}
                  onChange={(e) => setNewTask({...newTask, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={newTask.description}
                  onChange={(e) => setNewTask({...newTask, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  rows="3"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                <select
                  value={newTask.priority}
                  onChange={(e) => setNewTask({...newTask, priority: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                <input
                  type="date"
                  value={newTask.due_date}
                  onChange={(e) => setNewTask({...newTask, due_date: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                />
              </div>
              {/* Only show department selection for farm owners */}
              {user.role === 'farm_owner' && departments.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <select
                    value={newTask.department_id}
                    onChange={(e) => setNewTask({...newTask, department_id: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Select Department</option>
                    {departments.map(dept => (
                      <option key={dept.id} value={dept.id}>{dept.name}</option>
                    ))}
                  </select>
                </div>
              )}
              
              {/* Show current department for supervisors */}
              {user.role === 'supervisor' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                  <div className="w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-lg text-gray-700">
                    {user.department_name || 'Your Department'}
                  </div>
                </div>
              )}
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700"
                >
                  Add Task
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="space-y-4">
        {tasks.map((task) => (
          <div key={task.id} className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="text-lg font-semibold text-gray-900">{task.title}</h3>
                  {getPriorityBadge(task.priority)}
                  {getStatusBadge(task.status)}
                </div>
                {task.description && (
                  <p className="text-gray-600 mb-3">{task.description}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center ml-4">
                <CheckSquare className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            
            <div className="flex items-center justify-between text-sm text-gray-500">
              <div className="flex items-center space-x-4">
                {task.due_date && (
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>Due: {new Date(task.due_date).toLocaleDateString()}</span>
                  </div>
                )}
                {task.department_name && (
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>{task.department_name}</span>
                  </div>
                )}
              </div>
              <div className="text-xs">
                Created: {new Date(task.created_at).toLocaleDateString()}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Profile Component
const Profile = ({ user }) => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Profile</h1>
      
      <div className="bg-white p-8 rounded-xl shadow-md max-w-2xl">
        <div className="flex items-center space-x-6 mb-8">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
            <User className="w-10 h-10 text-green-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{user.username}</h2>
            <p className="text-gray-600 capitalize">{user.role?.replace('_', ' ')}</p>
            {user.department_name && (
              <p className="text-sm text-gray-500">Department: {user.department_name}</p>
            )}
          </div>
        </div>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
            <div className="p-3 bg-gray-50 rounded-lg text-gray-900">{user.username}</div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <div className="p-3 bg-gray-50 rounded-lg text-gray-900 flex items-center space-x-2">
              <Mail className="w-4 h-4 text-gray-500" />
              <span>{user.email}</span>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
            <div className="p-3 bg-gray-50 rounded-lg text-gray-900 capitalize">
              {user.role?.replace('_', ' ')}
            </div>
          </div>
          
          {user.department_name && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
              <div className="p-3 bg-gray-50 rounded-lg text-gray-900">
                {user.department_name}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Main App Component
const FarmManagementApp = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [token, setToken] = useState('');
  const [activeTab, setActiveTab] = useState('dashboard');

  // Check for existing authentication on component mount
  useEffect(() => {
    const savedToken = localStorage.getItem('farm_token');
    const savedUser = localStorage.getItem('farm_user');
    
    if (savedToken && savedUser) {
      try {
        setToken(savedToken);
        setUser(JSON.parse(savedUser));
        setIsAuthenticated(true);
      } catch (error) {
        // Clear invalid data
        localStorage.removeItem('farm_token');
        localStorage.removeItem('farm_user');
      }
    }
  }, []);

  const handleLogin = (newToken, newUser) => {
    setToken(newToken);
    setUser(newUser);
    setIsAuthenticated(true);
    
    // Save to localStorage for persistence
    localStorage.setItem('farm_token', newToken);
    localStorage.setItem('farm_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setToken('');
    setUser(null);
    setIsAuthenticated(false);
    setActiveTab('dashboard');
    
    // Clear from localStorage
    localStorage.removeItem('farm_token');
    localStorage.removeItem('farm_user');
  };

  // Render login screen if not authenticated
  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  // Render main dashboard
  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        user={user}
        onLogout={handleLogout}
      />
      
      <div className="flex-1 overflow-y-auto">
        {activeTab === 'dashboard' && <Dashboard token={token} user={user} />}
        {activeTab === 'reports' && <Reports token={token} user={user} />}
        {activeTab === 'activity' && <ActivityPage user={user} />}
        {activeTab === 'employees' && <EmployeeManagement token={token} user={user} />}
        {activeTab === 'tools' && <ToolManagement token={token} user={user} />}
        {activeTab === 'tasks' && <TaskManagement token={token} user={user} />}
        {activeTab === 'profile' && <Profile user={user} />}
      </div>
    </div>
  );
};

export default FarmManagementApp;